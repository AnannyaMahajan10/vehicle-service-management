/**
 * AutoCare Vehicle Service Management System (VSM)
 * Client-Side Interactivity, Validation & Modal Controllers
 */

document.addEventListener("DOMContentLoaded", function () {
    // -----------------------------------------------------------
    // 1. Mobile Navigation Toggle
    // -----------------------------------------------------------
    const navToggleBtn = document.getElementById("nav-toggle-btn");
    const navMenu = document.getElementById("nav-menu");

    if (navToggleBtn && navMenu) {
        navToggleBtn.addEventListener("click", function () {
            navMenu.classList.toggle("active");
        });
    }

    // -----------------------------------------------------------
    // 2. Dynamic Min Date Enforcement for Appointment Date
    // -----------------------------------------------------------
    const dateInput = document.getElementById("appointment_date");
    if (dateInput) {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, "0");
        const dd = String(today.getDate()).padStart(2, "0");
        const minDateStr = `${yyyy}-${mm}-${dd}`;
        dateInput.min = minDateStr;

        if (!dateInput.value) {
            dateInput.value = minDateStr;
        }

        dateInput.addEventListener("change", function () {
            if (this.value < minDateStr) {
                alert("Appointment date cannot be in the past. Automatically reset to today.");
                this.value = minDateStr;
            }
        });
    }

    // -----------------------------------------------------------
    // 3. Vehicle Plate Auto-Uppercase & Formatting
    // -----------------------------------------------------------
    const vehicleRegInput = document.getElementById("vehicle_reg");
    if (vehicleRegInput) {
        vehicleRegInput.addEventListener("input", function () {
            this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, "");
        });
    }

    // -----------------------------------------------------------
    // 4. Contact Number Digits Only & 10-Digit Constraint
    // -----------------------------------------------------------
    const contactInput = document.getElementById("contact_number");
    if (contactInput) {
        contactInput.addEventListener("input", function () {
            this.value = this.value.replace(/\D/g, "").slice(0, 10);
        });
    }

    // -----------------------------------------------------------
    // 5. Booking Form Client Validation
    // -----------------------------------------------------------
    const bookingForm = document.getElementById("booking-form");
    if (bookingForm) {
        bookingForm.addEventListener("submit", function (e) {
            const name = document.getElementById("customer_name")?.value.trim();
            const phone = document.getElementById("contact_number")?.value.trim();
            const reg = document.getElementById("vehicle_reg")?.value.trim();
            const model = document.getElementById("vehicle_model")?.value.trim();
            const service = document.getElementById("service_type")?.value;
            const timeSlot = document.getElementById("appointment_time")?.value;

            if (!name || name.length < 2) {
                alert("Please enter a valid customer name (at least 2 letters).");
                e.preventDefault();
                return;
            }

            const phonePattern = /^[6-9]\d{9}$/;
            if (!phone || !phonePattern.test(phone)) {
                alert("Please enter a valid 10-digit mobile number starting with 6, 7, 8, or 9.");
                e.preventDefault();
                return;
            }

            if (!reg || reg.length < 6) {
                alert("Please enter a valid vehicle registration plate (minimum 6 characters).");
                e.preventDefault();
                return;
            }

            if (!model) {
                alert("Please provide the vehicle make and model.");
                e.preventDefault();
                return;
            }

            if (!service) {
                alert("Please select a service type from the dropdown.");
                e.preventDefault();
                return;
            }

            if (!timeSlot) {
                alert("Please select a preferred appointment time slot.");
                e.preventDefault();
                return;
            }
        });
    }

    // -----------------------------------------------------------
    // 6. Auto-dismiss Flash Alerts after 6 seconds
    // -----------------------------------------------------------
    const alerts = document.querySelectorAll(".alert");
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = "opacity 0.4s ease, transform 0.4s ease";
            alert.style.opacity = "0";
            alert.style.transform = "translateY(-6px)";
            setTimeout(function () {
                alert.remove();
            }, 400);
        }, 6000);
    });

    // -----------------------------------------------------------
    // 7. Modal Esc-Key Listener
    // -----------------------------------------------------------
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") {
            closeUpdateModal();
        }
    });

    // Close modal when clicking on overlay background
    const modalOverlay = document.getElementById("status-modal");
    if (modalOverlay) {
        modalOverlay.addEventListener("click", function (e) {
            if (e.target === this) {
                closeUpdateModal();
            }
        });
    }
});

// -----------------------------------------------------------
// 8. Copy Booking ID Helper
// -----------------------------------------------------------
function copyBookingId(bookingId) {
    if (!bookingId) return;

    navigator.clipboard.writeText(bookingId).then(
        function () {
            const btn = document.getElementById("copy-booking-btn");
            if (btn) {
                const originalHtml = btn.innerHTML;
                btn.innerHTML = `
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                    Copied!
                `;
                btn.style.borderColor = "#10B981";
                btn.style.color = "#34D399";
                setTimeout(function () {
                    btn.innerHTML = originalHtml;
                    btn.style.borderColor = "";
                    btn.style.color = "";
                }, 2500);
            }
        },
        function () {
            prompt("Copy Booking ID manually:", bookingId);
        }
    );
}

// -----------------------------------------------------------
// 9. Staff Status Update Modal Open/Close Controls
// -----------------------------------------------------------
function openUpdateModal(bookingId, vehicleReg, currentStatus, latestRemarks) {
    const modal = document.getElementById("status-modal");
    if (!modal) return;

    document.getElementById("form-booking-id").value = bookingId;
    document.getElementById("modal-booking-id").textContent = bookingId;
    document.getElementById("modal-vehicle-reg").textContent = vehicleReg;
    
    const statusSelect = document.getElementById("modal-status-select");
    if (statusSelect) {
        statusSelect.value = currentStatus;
    }

    const remarksTextarea = document.getElementById("modal-remarks");
    if (remarksTextarea) {
        remarksTextarea.value = latestRemarks || "";
    }

    modal.classList.add("active");
    modal.setAttribute("aria-hidden", "false");
}

function closeUpdateModal() {
    const modal = document.getElementById("status-modal");
    if (modal) {
        modal.classList.remove("active");
        modal.setAttribute("aria-hidden", "true");
    }
}
