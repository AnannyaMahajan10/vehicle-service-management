# Vehicle Service Management System (VSM)
### Individual Project-Based Learning (PBL) Academic Project

---

## 📌 Project Overview
The **Vehicle Service Management System (VSM)** is a web-based full-stack application developed with **Python Flask**, **SQLite**, and **Vanilla HTML5/CSS3/JavaScript**. It fulfills the college Project-Based Learning (PBL) curriculum requirements by implementing two core functional modules:
1. **Module 1: Service Appointment Booking**
2. **Module 2: Service Status Tracking**

The project also features **role-based staff authorization**, **data validation**, **defect tracking using JIRA**, and an **automated test suite (Python unittest)**.

---

## 🛠️ Technology Stack
- **Frontend:** HTML5, CSS3 (Modern Glassmorphic UI with responsive flexbox/grid), Vanilla JavaScript (DOM validation & modal controllers)
- **Backend:** Python 3.10+ / Flask 3.x
- **Database:** SQLite 3 (ACID compliant, zero-configuration local database)
- **Project Management:** Atlassian JIRA (Scrum/Kanban, Epics, User Stories, Tasks, Defect Tracking)
- **Testing:** Python `unittest` test suite & Manual Functional Test Cases

---

## 📂 Project Directory Structure
```
vehicle-service-management/
├── app.py                     # Main Flask application & route controllers
├── database.py                # Database connection, queries & helper functions
├── schema.sql                 # SQLite schema definitions & constraints
├── requirements.txt           # Python package dependencies
├── vsm.db                     # Persistent SQLite database file
├── README.md                  # Complete documentation & quickstart guide
├── tests/
│   └── test_app.py            # Automated unittest test suite (16 test cases)
├── templates/
│   ├── base.html              # Base layout with navbar, alerts & footer
│   ├── index.html             # Landing page with live metrics & quick search
│   ├── book_service.html      # Module 1: Appointment booking form
│   ├── booking_confirmation.html # Booking slip & unique reference ID receipt
│   ├── track_service.html     # Module 2: 3-stage visual progress tracking
│   ├── staff_login.html       # Staff authorization login portal
│   └── staff_dashboard.html   # Staff operations queue & status update modal
└── static/
    ├── css/
    │   └── style.css          # Curated CSS3 styling & responsive media queries
    └── js/
        └── script.js          # Client-side validation, clipboard copy & modals
```

---

## ⚙️ Quick Setup & Execution (Windows PowerShell)

### Step 1: Open Terminal in Project Directory
Open **VS Code** or Windows PowerShell in `c:\Users\HP\Desktop\vehicle-service-management`.

### Step 2: (Optional) Create & Activate Virtual Environment
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Initialize the SQLite Database
```powershell
python -c "import database; database.init_db(); print('Database Ready!')"
```

### Step 5: Start the Flask Application
```powershell
python app.py
```
Open your web browser and navigate to:
**`http://127.0.0.1:5000`**

---

## 🔑 Default Credentials for Evaluation
- **Staff Portal URL:** `http://127.0.0.1:5000/staff/login`
- **Username:** `staff`
- **Password:** `staff123`
*(A convenient "Auto-fill Demo Credentials" button is also provided on the login page for effortless viva demonstration).*

---

## 🧪 Running the Automated Unit Test Suite
To execute all 16 automated test cases covering both modules, validation boundaries, authentication, and database persistence:
```powershell
python -m unittest discover -s tests -v
```
All tests run with isolated temporary SQLite databases and will output:
`Ran 16 tests in ... OK`.

---

## 📋 Evaluation Checklist for Viva Voce
| Feature / Requirement | Implementation Details | Where to View |
|---|---|---|
| **Module 1: Booking** | Validates 10-digit phone, plate format, past date restriction; generates unique ID `VSM-XXXXXX` | Click "Book Service" (`/book`) |
| **Module 2: Tracking** | 3-stage visual progress stepper (Pending &rarr; In Progress &rarr; Completed) | Click "Track Status" (`/track`) |
| **Staff Authorization** | RBAC session check (`@login_required`); customers cannot modify service status | `/staff/dashboard` & `/staff/login` |
| **Database Storage** | Persistent SQLite tables (`appointments`, `service_status`, `staff_users`) | `vsm.db` |
| **Automated Testing** | 16 comprehensive unit tests using Python `unittest` | `tests/test_app.py` |
| **JIRA Management** | 3 Epics, User Stories, Sprints, and Defect Workflow | Detailed in project report |
