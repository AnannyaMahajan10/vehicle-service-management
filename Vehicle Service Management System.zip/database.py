"""
Vehicle Service Management System (VSM) - Database Layer
Handles SQLite connections, schema initialization, seed data, and data access methods.
"""

import os
import sqlite3
import random
import string
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

# Default database file path in the project root directory
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DEFAULT_DB_PATH = os.path.join(BASE_DIR, "vsm.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")


def get_db_connection(db_path=None):
    """
    Establishes and returns a connection to the SQLite database.
    Configures row_factory to sqlite3.Row for dictionary-like column access.
    """
    path = db_path if db_path else DEFAULT_DB_PATH
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db(db_path=None, seed_demo_data=True):
    """
    Initializes the database schema and seeds initial staff credentials and sample data.
    """
    path = db_path if db_path else DEFAULT_DB_PATH
    conn = get_db_connection(path)

    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema_sql = f.read()

    conn.executescript(schema_sql)

    # Seed Default Staff Account if not exists
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM staff_users WHERE username = ?", ("staff",))
    if cursor.fetchone() is None:
        staff_pwd_hash = generate_password_hash("staff123")
        cursor.execute(
            """
            INSERT INTO staff_users (username, password_hash, full_name, role)
            VALUES (?, ?, ?, ?)
            """,
            ("staff", staff_pwd_hash, "Senior Service Advisor", "Service Manager"),
        )

    # Seed Demo Bookings if table is empty and seeding requested
    if seed_demo_data:
        cursor.execute("SELECT COUNT(*) as count FROM appointments")
        row = cursor.fetchone()
        if row and row["count"] == 0:
            demo_bookings = [
                {
                    "booking_id": "VSM-DEMO-101",
                    "customer_name": "Rahul Sharma",
                    "contact_number": "9876543210",
                    "vehicle_reg": "MH12AB1234",
                    "vehicle_model": "Honda City 2022",
                    "service_type": "Periodic Maintenance",
                    "appointment_date": datetime.now().strftime("%Y-%m-%d"),
                    "appointment_time": "10:30",
                    "special_instructions": "Check brake pads and change engine oil.",
                    "status": "In Progress",
                    "remarks": "Vehicle inspected on lift. Oil drain in progress.",
                    "updated_by": "Senior Service Advisor",
                },
                {
                    "booking_id": "VSM-DEMO-102",
                    "customer_name": "Priya Patel",
                    "contact_number": "9123456780",
                    "vehicle_reg": "DL01XY9876",
                    "vehicle_model": "Hyundai Creta SX",
                    "service_type": "General Service",
                    "appointment_date": datetime.now().strftime("%Y-%m-%d"),
                    "appointment_time": "14:00",
                    "special_instructions": "Air conditioning cooling check.",
                    "status": "Pending",
                    "remarks": "Appointment confirmed. Vehicle arrival awaited.",
                    "updated_by": "System",
                },
            ]

            for demo in demo_bookings:
                cursor.execute(
                    """
                    INSERT INTO appointments 
                    (booking_id, customer_name, contact_number, vehicle_reg, vehicle_model, service_type, appointment_date, appointment_time, special_instructions)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        demo["booking_id"],
                        demo["customer_name"],
                        demo["contact_number"],
                        demo["vehicle_reg"],
                        demo["vehicle_model"],
                        demo["service_type"],
                        demo["appointment_date"],
                        demo["appointment_time"],
                        demo["special_instructions"],
                    ),
                )
                cursor.execute(
                    """
                    INSERT INTO service_status 
                    (booking_id, status, remarks, updated_by)
                    VALUES (?, ?, ?, ?)
                    """,
                    (
                        demo["booking_id"],
                        demo["status"],
                        demo["remarks"],
                        demo["updated_by"],
                    ),
                )

    conn.commit()
    conn.close()


def generate_unique_booking_id(conn=None):
    """
    Generates a unique, friendly booking ID formatted as VSM-XXXXXX (e.g. VSM-7A9B2C).
    """
    should_close = False
    if conn is None:
        conn = get_db_connection()
        should_close = True

    while True:
        random_suffix = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
        candidate_id = f"VSM-{random_suffix}"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM appointments WHERE booking_id = ?", (candidate_id,))
        if cursor.fetchone() is None:
            if should_close:
                conn.close()
            return candidate_id


def create_appointment(data, db_path=None):
    """
    Creates a new service appointment and sets initial service status to 'Pending'.
    Returns the generated booking_id.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    booking_id = generate_unique_booking_id(conn)
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    cursor.execute(
        """
        INSERT INTO appointments 
        (booking_id, customer_name, contact_number, vehicle_reg, vehicle_model, service_type, appointment_date, appointment_time, special_instructions, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            booking_id,
            data["customer_name"].strip(),
            data["contact_number"].strip(),
            data["vehicle_reg"].strip().upper(),
            data["vehicle_model"].strip(),
            data["service_type"].strip(),
            data["appointment_date"].strip(),
            data["appointment_time"].strip(),
            data.get("special_instructions", "").strip(),
            now_str,
        ),
    )

    # Initial status entry
    cursor.execute(
        """
        INSERT INTO service_status (booking_id, status, remarks, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            booking_id,
            "Pending",
            "Appointment booked successfully. Awaiting vehicle drop-off at service center.",
            "System",
            now_str,
        ),
    )

    conn.commit()
    conn.close()
    return booking_id


def get_appointment_by_booking_id(booking_id, db_path=None):
    """
    Retrieves a single appointment by booking_id along with its current service status.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT 
            a.*,
            s.status AS current_status,
            s.remarks AS latest_remarks,
            s.updated_by AS last_updated_by,
            s.updated_at AS last_updated_at
        FROM appointments a
        LEFT JOIN service_status s ON s.id = (
            SELECT MAX(id) FROM service_status WHERE booking_id = a.booking_id
        )
        WHERE a.booking_id = ?
        """,
        (booking_id.strip(),),
    )
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None


def search_appointments(query_str, db_path=None):
    """
    Searches appointments by Booking ID (exact or partial) or Vehicle Registration Number.
    Returns a list of matching appointments with their current status.
    """
    if not query_str or not query_str.strip():
        return []

    clean_query = query_str.strip().upper()
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT 
            a.*,
            s.status AS current_status,
            s.remarks AS latest_remarks,
            s.updated_by AS last_updated_by,
            s.updated_at AS last_updated_at
        FROM appointments a
        LEFT JOIN service_status s ON s.id = (
            SELECT MAX(id) FROM service_status WHERE booking_id = a.booking_id
        )
        WHERE UPPER(a.booking_id) = ? 
           OR UPPER(a.vehicle_reg) = ?
           OR UPPER(a.booking_id) LIKE ?
        ORDER BY a.created_at DESC
        """,
        (clean_query, clean_query, f"%{clean_query}%"),
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_appointments(status_filter=None, search_term=None, db_path=None):
    """
    Retrieves all appointments, optionally filtered by status or search keyword.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    sql = """
        SELECT 
            a.*,
            s.status AS current_status,
            s.remarks AS latest_remarks,
            s.updated_by AS last_updated_by,
            s.updated_at AS last_updated_at
        FROM appointments a
        LEFT JOIN service_status s ON s.id = (
            SELECT MAX(id) FROM service_status WHERE booking_id = a.booking_id
        )
        WHERE 1=1
    """
    params = []

    if status_filter and status_filter in ["Pending", "In Progress", "Completed"]:
        sql += " AND s.status = ?"
        params.append(status_filter)

    if search_term and search_term.strip():
        term = f"%{search_term.strip().upper()}%"
        sql += " AND (UPPER(a.booking_id) LIKE ? OR UPPER(a.vehicle_reg) LIKE ? OR UPPER(a.customer_name) LIKE ?)"
        params.extend([term, term, term])

    sql += " ORDER BY a.appointment_date DESC, a.appointment_time DESC"

    cursor.execute(sql, params)
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_service_status(booking_id, new_status, remarks, updated_by="Staff", db_path=None):
    """
    Updates the service status for a given booking_id.
    Enforces valid status domain: 'Pending', 'In Progress', 'Completed'.
    Inserts a new status transition record to keep an audit trail.
    """
    valid_statuses = ("Pending", "In Progress", "Completed")
    if new_status not in valid_statuses:
        raise ValueError(f"Invalid status '{new_status}'. Allowed: {valid_statuses}")

    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    # Verify booking exists
    cursor.execute("SELECT id FROM appointments WHERE booking_id = ?", (booking_id,))
    if cursor.fetchone() is None:
        conn.close()
        return False

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute(
        """
        INSERT INTO service_status (booking_id, status, remarks, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (booking_id, new_status, remarks.strip() if remarks else "", updated_by, now_str),
    )
    conn.commit()
    conn.close()
    return True


def get_status_history(booking_id, db_path=None):
    """
    Retrieves full chronological status update history for a given booking.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT * FROM service_status 
        WHERE booking_id = ? 
        ORDER BY updated_at ASC, id ASC
        """,
        (booking_id,),
    )
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_dashboard_stats(db_path=None):
    """
    Calculates summary counts for total bookings, pending, in progress, and completed.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) AS total FROM appointments")
    total = cursor.fetchone()["total"]

    cursor.execute(
        """
        SELECT s.status, COUNT(*) AS count
        FROM appointments a
        JOIN service_status s ON s.id = (
            SELECT MAX(id) FROM service_status WHERE booking_id = a.booking_id
        )
        GROUP BY s.status
        """
    )
    rows = cursor.fetchall()
    conn.close()

    counts = {"Pending": 0, "In Progress": 0, "Completed": 0}
    for r in rows:
        if r["status"] in counts:
            counts[r["status"]] = r["count"]

    return {
        "total_bookings": total,
        "pending_count": counts["Pending"],
        "in_progress_count": counts["In Progress"],
        "completed_count": counts["Completed"],
    }


def authenticate_staff(username, password, db_path=None):
    """
    Verifies staff credentials against the hashed password in SQLite.
    Returns staff dictionary if authenticated, otherwise None.
    """
    if not username or not password:
        return None

    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM staff_users WHERE username = ?", (username.strip(),))
    user = cursor.fetchone()
    conn.close()

    if user and check_password_hash(user["password_hash"], password):
        return dict(user)
    return None
