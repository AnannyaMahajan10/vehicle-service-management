-- Vehicle Service Management System (VSM) Database Schema
-- Database: SQLite3

-- 1. Staff Users Table (For authorized workshop personnel)
CREATE TABLE IF NOT EXISTS staff_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT DEFAULT 'Service Advisor',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Appointments Table (Functional Module 1: Service Appointment Booking)
CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id TEXT UNIQUE NOT NULL,
    customer_name TEXT NOT NULL,
    contact_number TEXT NOT NULL,
    vehicle_reg TEXT NOT NULL,
    vehicle_model TEXT NOT NULL,
    service_type TEXT NOT NULL,
    appointment_date TEXT NOT NULL,
    appointment_time TEXT NOT NULL,
    special_instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Service Status Table (Functional Module 2: Service Status Tracking)
CREATE TABLE IF NOT EXISTS service_status (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('Pending', 'In Progress', 'Completed')),
    remarks TEXT,
    updated_by TEXT DEFAULT 'System',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES appointments(booking_id) ON DELETE CASCADE
);

-- Index for fast lookup by booking_id and vehicle_reg
CREATE INDEX IF NOT EXISTS idx_appointments_booking_id ON appointments(booking_id);
CREATE INDEX IF NOT EXISTS idx_appointments_vehicle_reg ON appointments(vehicle_reg);
CREATE INDEX IF NOT EXISTS idx_service_status_booking_id ON service_status(booking_id);
