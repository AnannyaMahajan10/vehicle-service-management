"""
Vehicle Service Management System (VSM) - Main Flask Application
College Project-Based Learning (PBL) Implementation
Modules Implemented:
  1. Service Appointment Booking
  2. Service Status Tracking
"""

import os
import re
from datetime import datetime, date
from functools import wraps
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    session,
    abort,
)
import database

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get(
    "SECRET_KEY", "vsm-college-pbl-project-secret-key-2026"
)

# Custom context processor to inject current date and year to templates
@app.context_processor
def inject_globals():
    return {
        "current_year": datetime.now().year,
        "today_date": date.today().strftime("%Y-%m-%d"),
    }


def login_required(f):
    """
    Decorator to restrict routes to authenticated staff members.
    Redirects unauthorized visitors to staff login with a warning.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("staff_logged_in"):
            flash("Staff authorization required. Please log in first.", "warning")
            return redirect(url_for("staff_login", next=request.url))
        return f(*args, **kwargs)

    return decorated_function


# -------------------------------------------------------------
# Input Validation Helper Functions
# -------------------------------------------------------------
def validate_contact_number(phone):
    """
    Validates mobile contact numbers: Must be exactly 10 digits.
    Accepts Indian/standard 10-digit mobile numbers without country code.
    """
    if not phone or not phone.strip():
        return False, "Invalid contact number. Contact number is required and must be 10 digits."
    clean_phone = phone.strip().replace(" ", "").replace("-", "")
    if not re.match(r"^[6-9]\d{9}$", clean_phone):
        return (
            False,
            "Invalid contact number. Must be a valid 10-digit mobile number starting with 6-9.",
        )
    return True, clean_phone


def validate_vehicle_reg(reg):
    """
    Validates vehicle registration format:
    Accepts standard vehicle number formats (e.g. MH12AB1234 or DL01A1234 or alphanumeric 6-12 chars).
    """
    if not reg:
        return False, "Vehicle registration number is required."
    clean_reg = reg.strip().upper().replace(" ", "").replace("-", "")
    # Check alphanumeric with length 6 to 12
    if not re.match(r"^[A-Z]{2}[0-9A-Z]{4,10}$", clean_reg):
        return (
            False,
            "Invalid vehicle registration number format (e.g., MH12AB1234).",
        )
    return True, clean_reg


def validate_appointment_date(date_str):
    """
    Prevents booking appointments for past dates.
    Appointment date must be today or future.
    """
    if not date_str:
        return False, "Appointment date is required."
    try:
        booking_date = datetime.strptime(date_str.strip(), "%Y-%m-%d").date()
        today = date.today()
        if booking_date < today:
            return False, "Appointment date cannot be in the past. Please select today or a future date."
        return True, date_str.strip()
    except ValueError:
        return False, "Invalid date format. Expected YYYY-MM-DD."


# -------------------------------------------------------------
# Routes
# -------------------------------------------------------------
@app.route("/")
def index():
    """
    Landing Page: Overview of the Vehicle Service Management System.
    Displays quick action cards and live workshop service statistics.
    """
    stats = database.get_dashboard_stats()
    return render_template("index.html", stats=stats)


# -------------------------------------------------------------
# Module 1: Service Appointment Booking
# -------------------------------------------------------------
@app.route("/book", methods=["GET", "POST"])
def book_service():
    """
    Service Appointment Booking:
    - GET: Displays the appointment booking form with service types and date selector.
    - POST: Validates input fields, generates unique booking ID, and persists to SQLite.
    """
    service_options = [
        "General Periodic Maintenance",
        "Engine Oil & Filter Replacement",
        "Brake Inspection & Pad Replacement",
        "Wheel Alignment & Tire Balancing",
        "Air Conditioning Service & Gas Refill",
        "Electrical & Battery Diagnostic Check",
        "Complete Vehicle Diagnostic & Repair",
    ]

    if request.method == "POST":
        customer_name = request.form.get("customer_name", "").strip()
        contact_number = request.form.get("contact_number", "").strip()
        vehicle_reg = request.form.get("vehicle_reg", "").strip()
        vehicle_model = request.form.get("vehicle_model", "").strip()
        service_type = request.form.get("service_type", "").strip()
        appointment_date = request.form.get("appointment_date", "").strip()
        appointment_time = request.form.get("appointment_time", "").strip()
        special_instructions = request.form.get("special_instructions", "").strip()

        # Collect validation errors
        errors = []

        if not customer_name:
            errors.append("Customer name is required.")
        elif len(customer_name) < 2:
            errors.append("Customer name must be at least 2 characters.")

        is_phone_valid, phone_result = validate_contact_number(contact_number)
        if not is_phone_valid:
            errors.append(phone_result)
        else:
            contact_number = phone_result

        is_reg_valid, reg_result = validate_vehicle_reg(vehicle_reg)
        if not is_reg_valid:
            errors.append(reg_result)
        else:
            vehicle_reg = reg_result

        if not vehicle_model:
            errors.append("Vehicle model (e.g., Honda City, Hyundai i20) is required.")

        if not service_type or service_type not in service_options:
            errors.append("Please select a valid service type from the dropdown.")

        is_date_valid, date_result = validate_appointment_date(appointment_date)
        if not is_date_valid:
            errors.append(date_result)

        if not appointment_time:
            errors.append("Please choose a preferred appointment time slot.")

        if errors:
            for err in errors:
                flash(err, "error")
            return render_template(
                "book_service.html",
                service_options=service_options,
                form_data=request.form,
            ), 400

        # Save to database
        try:
            booking_data = {
                "customer_name": customer_name,
                "contact_number": contact_number,
                "vehicle_reg": vehicle_reg,
                "vehicle_model": vehicle_model,
                "service_type": service_type,
                "appointment_date": appointment_date,
                "appointment_time": appointment_time,
                "special_instructions": special_instructions,
            }
            booking_id = database.create_appointment(booking_data)
            flash(
                f"Service appointment booked successfully! Your Booking ID is {booking_id}.",
                "success",
            )
            return redirect(url_for("booking_confirmation", booking_id=booking_id))
        except Exception as e:
            flash(f"Database error while saving booking: {str(e)}", "error")
            return render_template(
                "book_service.html",
                service_options=service_options,
                form_data=request.form,
            ), 500

    return render_template("book_service.html", service_options=service_options, form_data={})


@app.route("/confirmation/<booking_id>")
def booking_confirmation(booking_id):
    """
    Displays the appointment confirmation receipt card with the generated Booking ID.
    """
    appointment = database.get_appointment_by_booking_id(booking_id)
    if not appointment:
        flash(f"Booking ID '{booking_id}' not found.", "error")
        return redirect(url_for("book_service"))
    return render_template("booking_confirmation.html", appointment=appointment)


# -------------------------------------------------------------
# Module 2: Service Status Tracking
# -------------------------------------------------------------
@app.route("/track", methods=["GET", "POST"])
def track_service():
    """
    Service Status Tracking:
    Allows customers to look up service progress using Booking ID or Vehicle Reg.
    Read-only view: customers cannot alter the status.
    """
    query = request.args.get("query", "").strip()
    if request.method == "POST":
        query = request.form.get("query", "").strip()
        if query:
            return redirect(url_for("track_service", query=query))

    results = []
    searched = False

    if query:
        searched = True
        results = database.search_appointments(query)
        if not results:
            flash(
                f"No service record found matching '{query}'. Please verify your Booking ID or Vehicle Number.",
                "info",
            )

    return render_template(
        "track_service.html",
        query=query,
        results=results,
        searched=searched,
    )


# -------------------------------------------------------------
# Staff Authentication & Authorized Management
# -------------------------------------------------------------
@app.route("/staff/login", methods=["GET", "POST"])
def staff_login():
    """
    Staff Authentication Login:
    Verifies staff username and password hash against SQLite staff_users table.
    """
    if session.get("staff_logged_in"):
        return redirect(url_for("staff_dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        if not username or not password:
            flash("Please enter both username and password.", "error")
            return render_template("staff_login.html"), 400

        user = database.authenticate_staff(username, password)
        if user:
            session["staff_logged_in"] = True
            session["staff_id"] = user["id"]
            session["staff_username"] = user["username"]
            session["staff_name"] = user["full_name"]
            session["staff_role"] = user["role"]
            flash(f"Welcome back, {user['full_name']}!", "success")
            next_page = request.args.get("next")
            return redirect(next_page or url_for("staff_dashboard"))
        else:
            flash("Invalid staff username or password.", "error")
            return render_template("staff_login.html"), 401

    return render_template("staff_login.html")


@app.route("/staff/logout")
def staff_logout():
    """
    Logs out the staff user and clears the session.
    """
    session.clear()
    flash("You have been logged out of the staff portal.", "info")
    return redirect(url_for("staff_login"))


@app.route("/staff/dashboard")
@login_required
def staff_dashboard():
    """
    Staff Service Management Dashboard:
    - Requires authenticated staff session.
    - Shows stats, filterable bookings list, and status update controls.
    """
    status_filter = request.args.get("status", "").strip()
    search_keyword = request.args.get("search", "").strip()

    stats = database.get_dashboard_stats()
    appointments = database.get_all_appointments(
        status_filter=status_filter if status_filter else None,
        search_term=search_keyword if search_keyword else None,
    )

    return render_template(
        "staff_dashboard.html",
        stats=stats,
        appointments=appointments,
        current_filter=status_filter,
        search_keyword=search_keyword,
    )


@app.route("/staff/update-status", methods=["POST"])
@login_required
def update_status():
    """
    Authorized Status Update Endpoint:
    Enforces staff authorization (via @login_required).
    Validates status values: 'Pending', 'In Progress', 'Completed'.
    Saves change in database and redirects back with confirmation.
    """
    booking_id = request.form.get("booking_id", "").strip()
    new_status = request.form.get("status", "").strip()
    remarks = request.form.get("remarks", "").strip()

    if not booking_id:
        flash("Missing Booking ID.", "error")
        return redirect(url_for("staff_dashboard"))

    valid_statuses = ["Pending", "In Progress", "Completed"]
    if new_status not in valid_statuses:
        flash(f"Invalid status value '{new_status}'. Allowed: {', '.join(valid_statuses)}.", "error")
        return redirect(url_for("staff_dashboard"))

    staff_name = session.get("staff_name", "Service Advisor")
    success = database.update_service_status(
        booking_id=booking_id,
        new_status=new_status,
        remarks=remarks,
        updated_by=staff_name,
    )

    if success:
        flash(
            f"Service status for booking #{booking_id} updated to '{new_status}' successfully.",
            "success",
        )
    else:
        flash(f"Failed to update: Booking ID '{booking_id}' not found.", "error")

    return redirect(url_for("staff_dashboard"))


# -------------------------------------------------------------
# Error Handlers
# -------------------------------------------------------------
@app.errorhandler(404)
def not_found_error(error):
    return render_template("base.html", error_title="404 - Page Not Found", error_message="The requested page could not be found."), 404


@app.errorhandler(403)
def forbidden_error(error):
    return render_template("base.html", error_title="403 - Forbidden", error_message="You are not authorized to perform this action."), 403


@app.errorhandler(500)
def internal_error(error):
    return render_template("base.html", error_title="500 - Server Error", error_message="An unexpected server error occurred. Please try again."), 500


if __name__ == "__main__":
    # Ensure database tables exist before starting server
    database.init_db()
    print("=" * 60)
    print(" Vehicle Service Management System (PBL Project)")
    print(" Running at: http://127.0.0.1:5000")
    print(" Default Staff Login: username='staff' | password='staff123'")
    print("=" * 60)
    app.run(debug=True, port=5000)
