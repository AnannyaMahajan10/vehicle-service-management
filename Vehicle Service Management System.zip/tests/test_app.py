"""
Vehicle Service Management System (VSM) - Automated Unit Test Suite
Framework: Python unittest
Modules Tested:
  - Functional Module 1: Service Appointment Booking
  - Functional Module 2: Service Status Tracking
  - Security & Authorization: Staff Authentication & RBAC
  - Database Layer: Data Persistence & Validation Constraints
"""

import os
import tempfile
import unittest
from datetime import date, timedelta
from app import app
import database


class VehicleServiceManagementTestCase(unittest.TestCase):
    def setUp(self):
        """
        Creates a temporary SQLite database for test isolation before each test.
        Initializes schema and seeds demo staff account and initial records.
        """
        self.db_fd, self.temp_db_path = tempfile.mkstemp(suffix=".db")
        database.DEFAULT_DB_PATH = self.temp_db_path
        database.init_db(db_path=self.temp_db_path, seed_demo_data=True)

        app.config["TESTING"] = True
        app.config["SECRET_KEY"] = "test-secret-key-pbl"
        self.client = app.test_client()

    def tearDown(self):
        """
        Closes and removes the temporary database after each test.
        """
        os.close(self.db_fd)
        if os.path.exists(self.temp_db_path):
            os.remove(self.temp_db_path)

    # -------------------------------------------------------------
    # Test Module 1: Service Appointment Booking
    # -------------------------------------------------------------
    def test_tc01_valid_appointment_booking(self):
        """
        TC-01: Verify successful booking when all valid details are provided.
        """
        tomorrow = (date.today() + timedelta(days=1)).strftime("%Y-%m-%d")
        payload = {
            "customer_name": "Vikram Singh",
            "contact_number": "9811223344",
            "vehicle_reg": "MH12CD5678",
            "vehicle_model": "Maruti Brezza 2023",
            "service_type": "Engine Oil & Filter Replacement",
            "appointment_date": tomorrow,
            "appointment_time": "10:30 AM",
            "special_instructions": "Check coolant level.",
        }
        response = self.client.post("/book", data=payload, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Booking Confirmed", response.data)
        self.assertIn(b"Vikram Singh", response.data)
        self.assertIn(b"MH12CD5678", response.data)

        # Verify database record exists with 'Pending' initial status
        records = database.search_appointments("MH12CD5678", db_path=self.temp_db_path)
        self.assertEqual(len(records), 1)
        self.assertEqual(records[0]["current_status"], "Pending")

    def test_tc02_booking_missing_customer_name(self):
        """
        TC-02: Verify booking fails when mandatory Customer Name is missing.
        """
        tomorrow = (date.today() + timedelta(days=1)).strftime("%Y-%m-%d")
        payload = {
            "customer_name": "",
            "contact_number": "9811223344",
            "vehicle_reg": "MH12CD5678",
            "vehicle_model": "Maruti Brezza",
            "service_type": "Engine Oil & Filter Replacement",
            "appointment_date": tomorrow,
            "appointment_time": "10:30 AM",
        }
        response = self.client.post("/book", data=payload, follow_redirects=True)
        self.assertEqual(response.status_code, 400)
        self.assertIn(b"Customer name is required", response.data)

    def test_tc03_booking_invalid_contact_number(self):
        """
        TC-03: Verify booking rejection for invalid contact numbers (e.g. 5 digits or letters).
        """
        tomorrow = (date.today() + timedelta(days=1)).strftime("%Y-%m-%d")
        invalid_contacts = ["12345", "98765abcde", "1234567890", ""]
        for contact in invalid_contacts:
            payload = {
                "customer_name": "Amit Roy",
                "contact_number": contact,
                "vehicle_reg": "MH12CD5678",
                "vehicle_model": "Maruti Brezza",
                "service_type": "General Periodic Maintenance",
                "appointment_date": tomorrow,
                "appointment_time": "10:30 AM",
            }
            response = self.client.post("/book", data=payload, follow_redirects=True)
            self.assertEqual(response.status_code, 400)
            self.assertIn(b"Invalid contact number", response.data)

    def test_tc04_booking_invalid_vehicle_reg(self):
        """
        TC-04: Verify rejection of invalid vehicle registration plates.
        """
        tomorrow = (date.today() + timedelta(days=1)).strftime("%Y-%m-%d")
        payload = {
            "customer_name": "Amit Roy",
            "contact_number": "9876543210",
            "vehicle_reg": "123",  # Too short / invalid format
            "vehicle_model": "Maruti Brezza",
            "service_type": "General Periodic Maintenance",
            "appointment_date": tomorrow,
            "appointment_time": "10:30 AM",
        }
        response = self.client.post("/book", data=payload, follow_redirects=True)
        self.assertEqual(response.status_code, 400)
        self.assertIn(b"Invalid vehicle registration number format", response.data)

    def test_tc05_booking_past_appointment_date(self):
        """
        TC-05: Verify prevention of booking appointments for past dates.
        """
        yesterday = (date.today() - timedelta(days=1)).strftime("%Y-%m-%d")
        payload = {
            "customer_name": "Sunil Verma",
            "contact_number": "9876543210",
            "vehicle_reg": "MH12CD5678",
            "vehicle_model": "Honda City",
            "service_type": "General Periodic Maintenance",
            "appointment_date": yesterday,
            "appointment_time": "10:30 AM",
        }
        response = self.client.post("/book", data=payload, follow_redirects=True)
        self.assertEqual(response.status_code, 400)
        self.assertIn(b"Appointment date cannot be in the past", response.data)

    def test_tc06_booking_invalid_service_type(self):
        """
        TC-06: Verify rejection when an unauthorized service type is injected.
        """
        tomorrow = (date.today() + timedelta(days=1)).strftime("%Y-%m-%d")
        payload = {
            "customer_name": "Sunil Verma",
            "contact_number": "9876543210",
            "vehicle_reg": "MH12CD5678",
            "vehicle_model": "Honda City",
            "service_type": "NonExistentServicePackage",
            "appointment_date": tomorrow,
            "appointment_time": "10:30 AM",
        }
        response = self.client.post("/book", data=payload, follow_redirects=True)
        self.assertEqual(response.status_code, 400)
        self.assertIn(b"Please select a valid service type", response.data)

    # -------------------------------------------------------------
    # Test Module 2: Service Status Tracking
    # -------------------------------------------------------------
    def test_tc07_track_valid_booking_id(self):
        """
        TC-07: Verify customer search using a valid Booking ID returns service details.
        """
        response = self.client.get("/track?query=VSM-DEMO-101")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"VSM-DEMO-101", response.data)
        self.assertIn(b"In Service Bay", response.data)
        self.assertIn(b"Rahul Sharma", response.data)

    def test_tc08_track_valid_vehicle_registration(self):
        """
        TC-08: Verify customer search using vehicle plate number returns matching record.
        """
        response = self.client.get("/track?query=MH12AB1234")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"MH12AB1234", response.data)
        self.assertIn(b"Honda City 2022", response.data)

    def test_tc09_track_nonexistent_booking_id(self):
        """
        TC-09: Verify friendly notification when searching for a nonexistent booking ID.
        """
        response = self.client.get("/track?query=VSM-NONEXISTENT-999")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"No Matching Service Record Found", response.data)

    # -------------------------------------------------------------
    # Test Module 3: Staff Authentication & Authorization (RBAC)
    # -------------------------------------------------------------
    def test_tc10_staff_login_valid_credentials(self):
        """
        TC-10: Verify staff authentication succeeds with valid credentials.
        """
        response = self.client.post(
            "/staff/login",
            data={"username": "staff", "password": "staff123"},
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Workshop Operations Hub", response.data)
        self.assertIn(b"Senior Service Advisor", response.data)

    def test_tc11_staff_login_invalid_credentials(self):
        """
        TC-11: Verify staff authentication fails with incorrect password.
        """
        response = self.client.post(
            "/staff/login",
            data={"username": "staff", "password": "wrongpassword"},
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 401)
        self.assertIn(b"Invalid staff username or password", response.data)

    def test_tc12_unauthorized_dashboard_access_redirect(self):
        """
        TC-12: Verify unauthenticated visitor attempting to access /staff/dashboard is redirected.
        """
        response = self.client.get("/staff/dashboard", follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Staff authorization required", response.data)
        self.assertIn(b"Service Center Staff Login", response.data)

    def test_tc13_unauthorized_status_update_blocked(self):
        """
        TC-13: Verify unauthorized POST to /staff/update-status without login session is blocked.
        """
        payload = {
            "booking_id": "VSM-DEMO-102",
            "status": "In Progress",
            "remarks": "Malicious direct post attempt",
        }
        response = self.client.post("/staff/update-status", data=payload, follow_redirects=True)
        # Should redirect to staff login
        self.assertIn(b"Staff authorization required", response.data)

        # Status must remain unchanged in DB
        booking = database.get_appointment_by_booking_id("VSM-DEMO-102", db_path=self.temp_db_path)
        self.assertEqual(booking["current_status"], "Pending")

    def test_tc14_authorized_status_update_flow(self):
        """
        TC-14: Verify authorized staff can successfully progress status from Pending to In Progress, then Completed.
        """
        # Step 1: Log in as staff
        with self.client.session_transaction() as sess:
            sess["staff_logged_in"] = True
            sess["staff_name"] = "Senior Service Advisor"
            sess["staff_role"] = "Service Manager"

        # Step 2: Transition VSM-DEMO-102 from 'Pending' to 'In Progress'
        response = self.client.post(
            "/staff/update-status",
            data={
                "booking_id": "VSM-DEMO-102",
                "status": "In Progress",
                "remarks": "Vehicle pulled onto service lift #2. Inspection started.",
            },
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"updated to &#39;In Progress&#39; successfully", response.data)

        record = database.get_appointment_by_booking_id("VSM-DEMO-102", db_path=self.temp_db_path)
        self.assertEqual(record["current_status"], "In Progress")

        # Step 3: Transition to 'Completed'
        response2 = self.client.post(
            "/staff/update-status",
            data={
                "booking_id": "VSM-DEMO-102",
                "status": "Completed",
                "remarks": "Service complete. Wash and vacuum done. Ready for handover.",
            },
            follow_redirects=True,
        )
        self.assertEqual(response2.status_code, 200)
        record2 = database.get_appointment_by_booking_id("VSM-DEMO-102", db_path=self.temp_db_path)
        self.assertEqual(record2["current_status"], "Completed")

    def test_tc15_invalid_status_value_rejected(self):
        """
        TC-15: Verify system rejects invalid status domains (e.g., 'Cancelled' or arbitrary values).
        """
        with self.client.session_transaction() as sess:
            sess["staff_logged_in"] = True
            sess["staff_name"] = "Senior Service Advisor"

        response = self.client.post(
            "/staff/update-status",
            data={
                "booking_id": "VSM-DEMO-101",
                "status": "InvalidStatusXYZ",
                "remarks": "Invalid status test",
            },
            follow_redirects=True,
        )
        self.assertIn(b"Invalid status value", response.data)

    def test_tc16_database_persistence_across_connections(self):
        """
        TC-16: Verify data persistence in SQLite across isolated connection lifecycles.
        """
        booking_data = {
            "customer_name": "Kavita Rao",
            "contact_number": "9199887766",
            "vehicle_reg": "KA03MM4455",
            "vehicle_model": "Tata Nexon EV",
            "service_type": "Electrical & Battery Diagnostic Check",
            "appointment_date": (date.today() + timedelta(days=2)).strftime("%Y-%m-%d"),
            "appointment_time": "12:00 PM",
            "special_instructions": "Check battery pack diagnostics.",
        }
        b_id = database.create_appointment(booking_data, db_path=self.temp_db_path)

        # Re-open database with a completely fresh connection
        conn2 = database.get_db_connection(self.temp_db_path)
        cursor = conn2.cursor()
        cursor.execute("SELECT * FROM appointments WHERE booking_id = ?", (b_id,))
        row = cursor.fetchone()
        conn2.close()

        self.assertIsNotNone(row)
        self.assertEqual(row["customer_name"], "Kavita Rao")
        self.assertEqual(row["vehicle_reg"], "KA03MM4455")


if __name__ == "__main__":
    unittest.main()
